# Task 6: HTML Frontend Project

### 🔗 LinkedIn Post:
[Task 6: HTML Frontend Project](https://www.linkedin.com/posts/varshitha-naini-19225232a_webdevelopment-html-frontend-activity-7309923404478889984-aRF1)

### 📝 Description:
Created a structured and semantic frontend layout using HTML.
