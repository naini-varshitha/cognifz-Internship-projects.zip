# Task 5: Responsive Design with CSS

### 🔗 LinkedIn Post:
[Task 5: Responsive Design with CSS](https://www.linkedin.com/posts/varshitha-naini-19225232a_webdevelopment-css-responsivedesign-activity-7309924579483734017-Qxnf)

### 📝 Description:
Applied responsive design principles using CSS media queries.
