# Task 4: JavaScript and Frontend Interaction

### 🔗 LinkedIn Post:
[Task 4: JavaScript and Frontend Interaction](https://www.linkedin.com/posts/varshitha-naini-19225232a_webdevelopment-javascript-frontend-activity-7309925256855490560-2x8f)

### 📝 Description:
Demonstrated DOM manipulation and event handling with JavaScript.
