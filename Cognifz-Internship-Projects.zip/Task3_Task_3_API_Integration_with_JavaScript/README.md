# Task 3: API Integration with JavaScript

### 🔗 LinkedIn Post:
[Task 3: API Integration with JavaScript](https://www.linkedin.com/posts/varshitha-naini-19225232a_webdevelopment-apiintegration-javascript-activity-7309926660328304640-Bt-J)

### 📝 Description:
Integrated APIs using JavaScript to fetch and display dynamic data.
