# Task 1: HTML with Bootstrap

### 🔗 LinkedIn Post:
[Task 1: HTML with Bootstrap](https://www.linkedin.com/posts/varshitha-naini-19225232a_webdevelopment-html-bootstrap-activity-7309931048824381440-tuko)

### 📝 Description:
Created a responsive web page using HTML and Bootstrap framework.
