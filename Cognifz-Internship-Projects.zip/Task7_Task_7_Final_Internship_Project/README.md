# Task 7: Final Internship Project

### 🔗 LinkedIn Post:
[Task 7: Final Internship Project](https://www.linkedin.com/posts/varshitha-naini-19225232a_internship-project-frontenddevelopment-activity-7309921327354650625-L7I6)

### 📝 Description:
Completed and showcased the final project for the Cognifz internship using all frontend technologies.
