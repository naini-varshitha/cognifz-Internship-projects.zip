# Task 2: HTML and CSS Basics

### 🔗 LinkedIn Post:
[Task 2: HTML and CSS Basics](https://www.linkedin.com/posts/varshitha-naini-19225232a_webdevelopment-html-css-activity-7309928516886634496-ib8Q)

### 📝 Description:
Built a basic layout using HTML and styled it using CSS.
